from django.shortcuts import render

def dashboard_candidato(request):
    return render(request, 'dashboard_candidato.html')

def perfil_candidato(request):
    return render(request, 'perfil_candidato.html')

def explorar_vagas(request):
    return render(request, 'explorar_vagas.html')

def minhas_candidaturas(request):
    return render(request, 'candidaturas_vagas.html')

def caixa_mensagens(request):
    return render(request, 'mensagens.html')

def chat_ia(request):
    return render(request, 'chat_ia.html')

def cursos(request):
    return render(request, 'cursos.html')

def conf(request):
    return render(request, 'conf.html')

