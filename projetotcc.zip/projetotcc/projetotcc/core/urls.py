# core/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard_candidato, name='dashboard_candidato'),
    path('perfil/', views.perfil_candidato, name='perfil_candidato'),
    path('vagas/', views.explorar_vagas, name='explorar_vagas'),
    path('candidaturas/', views.minhas_candidaturas, name='minhas_candidaturas'),
    path('mensagens/', views.caixa_mensagens, name='caixa_mensagens'),
    path('chat-ia/', views.chat_ia, name='chat_ia'),
    path('cursos/', views.cursos, name='cursos'),
    path('configuracoes/', views.conf, name='conf'),
]

